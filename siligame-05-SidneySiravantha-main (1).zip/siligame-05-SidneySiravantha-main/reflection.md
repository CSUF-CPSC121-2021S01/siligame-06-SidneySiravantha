# Milestone 5

## Description
Describe what you did for this milestone in your own words.
I made my opponents, player projectiles, and opponent projectiles using unique pointers, and added mechanics that properly tracks player's progress in the game.

## Challenges encountered
Describe the challenges you encountered while working on this milestone of the project.
The hard part was definitely converting my existing code to utilize unique pointers, the dereferencing part is still confusing to me.

## Things I've learned
What is the most important thing you've learned from this milestone in the project?
I got better practice with pointers, and I think that is really important to me.
